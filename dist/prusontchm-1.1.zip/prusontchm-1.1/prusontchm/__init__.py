# this is a package
__version__ = '1.1'
__description__ = 'Practica 3'