# this is a package
__version__ = '1.2'
__description__ = 'Practica 3'